import React, { Component } from 'react';
import '../stylesheets/landingpage.css'
import $ from 'jquery'
import * as action from '../actions/action.js'
import { connect } from 'react-redux'

const mapStateToProps = state => ({
    GetDataState: state.GetDataReducer.GetDataState,
})

const mapDispatchToProps = dispatch => ({
    fetchGetData() {
        dispatch(
            action.GetDataAction()
        )
    },
})


class LandingPageComp extends Component {
    constructor(props) {
        super(props);
        this.state = {

        };
    }

    componentDidMount() {
        this.props.fetchGetData()
    }
    render() {
        const { GetDataState } = this.props
        // console.log(GetDataState)
        const height = $(window).height()
        return (
            <div className="col-sm-12" style={{ minHeight: height }}>
                <div class="container">
                    <h2>ORMAE Assignment</h2>

                    <table class="table table-hover">
                        <thead>
                            <tr>
                                <th>Title</th>
                                <th>Url</th>
                                <th>ThumbnailUrl</th>
                            </tr>
                        </thead>
                        <tbody>
                            {GetDataState.length > 0 ?
                                <React.Fragment>
                                    {GetDataState.map((tableField, index) => {
                                        return (
                                            <tr>
                                                <td>{tableField.title}</td>
                                                <td>{tableField.url}</td>
                                                <td>{tableField.thumbnailUrl}</td>
                                            </tr>
                                        )
                                    })

                                    }

                                </React.Fragment> : ""
                            }
                        </tbody>
                    </table>
                </div>
            </div>
        )

    }
}
const LandingPage = connect(mapStateToProps, mapDispatchToProps)(LandingPageComp)
export default LandingPage
