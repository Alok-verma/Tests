
const all = {
    serviceUrl: "http://jsonplaceholder.typicode.com/photos",
}

export default all;